import os
import shutil
import subprocess
import numpy as np
import math





# Calculate the minimum unit cells needed for GCMC simulation
def cell_units(lens, angs, co):
    # lens and cutoff (co) are given in A and angs in degrees
    # unpack parameters
    a = lens[0]
    b = lens[1]
    c = lens[2]
    alpha = math.radians(angs[0])
    beta = math.radians(angs[1])
    gamma = math.radians(angs[2])
    # Start the calculations (https://en.wikipedia.org/wiki/Fractional_coordinates)
    K = c*(math.cos(alpha)-math.cos(beta)*math.cos(gamma))/math.sin(gamma)
    V = math.sqrt(1-math.cos(alpha)**2-math.cos(beta)**2-math.cos(gamma)**2+2*math.cos(alpha)*math.cos(beta)*math.cos(gamma))
    Minv = [[a, 0, 0], [b*math.cos(gamma), b*math.sin(gamma), 0] , [c*math.cos(beta), K, c*V/math.sin(gamma)]]
    axb = np.cross(Minv[0],Minv[1])
    bxc = np.cross(Minv[1],Minv[2])
    cxa = np.cross(Minv[2],Minv[0])
    x = np.dot(Minv[0],bxc)/np.linalg.norm(bxc)
    y = np.dot(Minv[1],cxa)/np.linalg.norm(cxa)
    z = np.dot(Minv[2],axb)/np.linalg.norm(axb)
    xmin = math.ceil(2*co/x)
    ymin = math.ceil(2*co/y)
    zmin = math.ceil(2*co/z)
    return xmin, ymin, zmin



# Extract the edge lengths and angles from the .cif file
def extract_geometry(structure):
    with open (structure + '.cif', 'r') as fi:
        data = fi.readlines()
        for line in data:
            if "_cell_length_a" in line:
                a = float(line.split()[1])
            elif "_cell_length_b" in line:
                b = float(line.split()[1])
            elif "_cell_length_c" in line:
                c = float(line.split()[1])
            elif "_cell_angle_alpha" in line:
                alpha = float(line.split()[1])
            elif "_cell_angle_beta" in line:
                beta = float(line.split()[1])
            elif "_cell_angle_gamma" in line:
                gamma = float(line.split()[1])
        lens = [a, b, c]
        angs = [alpha, beta, gamma]
        fi.close()
    unitcell = cell_units(lens, angs, 12)
    return unitcell




# Create a simulation.input file for widom calculations
def widom(structure, unitcell, T, molecule, block):
    # T is in (K)
    with open("simulation.input","w") as fo:
        str_out = ""
        str_out += "SimulationType               MonteCarlo\n"
        str_out += "NumberOfCycles               10000\n"
        str_out += "NumberOfInitializationCycles 10000\n"
        str_out += "PrintEvery                   1000\n"
        str_out += "PrintPropertiesEvery         1000\n"
        str_out += "RestartFile                  no\n\n"
        str_out += "Forcefield                   local\n\n"
        str_out += "Framework               0\n"
        str_out += "FrameworkName           %s\n"%(structure)
        str_out += "UseChargesFromCIFFile        yes\n"
        str_out += "UnitCells               %i %i %i\n"%(unitcell[0],unitcell[1],unitcell[2])
        str_out += "ExternalTemperature     %s\n\n"%str(T)
        str_out += "Component 0 MoleculeName                 %s\n"%(molecule)
        str_out += "            MoleculeDefinition           local\n"
        if (block == "yes"):
            str_out += "            BlockPockets                 %s\n"%(block)
            str_out += "            BlockPocketsFilename         %s\n"%(structure)
        str_out += "            WidomProbability             1.0\n"
        str_out += "            CreateNumberOfMolecules      0\n"
        fo.write(str_out)
        fo.close()


# Extract Henry coefficient and heat of adsorption from a widom output file
def extract_widom(structure, molecule, unitcell, T):
    with open ("output_"+ structure + "_" + str(unitcell[0]) + "." +
               str(unitcell[1]) + "." + str(unitcell[2]) + "_" +
               str(T) + "0000_0" + ".data", 'r') as fi:
        data = fi.readlines()
        for line in data:
            if "[" + molecule + "]" + " Average Henry coefficient:" in line:
                Kh = float(line.split()[4])
                Kh_err=float(line.split()[6])
            elif "[" + molecule + "]" + " Average" + "  <U_gh>" in line:
                ads_ene = float(line.split()[8])
                ads_err=float(line.split()[10])
    # R (J/mmol.K)
    Q = ads_ene - 0.0083145*T
    Q_err= ads_err #this RT term does not need to be subtracted from the error again 
    fi.close()
    # Kh (mmol/g.Pa) and Q (J/mmol)
    return Kh, Kh_err, Q, Q_err


# Create a simulation.input file for GCMC calculations
def GCMC1(cycles, structure, unitcell, T, P, molecule, block):
    # T and P are in (K) and (Pa) respectively
    with open("simulation.input","a+") as fo:
        str_out = ""
        str_out += "SimulationType               MonteCarlo\n"
        str_out += "NumberOfCycles               %i\n"%(cycles)
        str_out += "NumberOfInitializationCycles %i\n"%(cycles)
        str_out += "PrintEvery                   %i\n"%(cycles/10)
        str_out += "PrintPropertiesEvery         %i\n"%(cycles/10)
        str_out += "RestartFile                  no\n\n"
        str_out += "CutOff                       12\n"
        str_out += "Forcefield                   local\n\n"
        str_out += "Framework               0\n"
        str_out += "FrameworkName           %s\n"%(structure)
        str_out += "UseChargesFromCIFFile   yes\n"
        str_out += "UnitCells               %i %i %i\n"%(unitcell[0],unitcell[1],unitcell[2])
        str_out += "ExternalTemperature     %s\n"%str(T)
        str_out += "ExternalPressure        %s\n\n"%str(P)
        str_out += "Component 0 MoleculeName                 %s\n"%(molecule)
        str_out += "            MoleculeDefinition           local\n"
        if (block == "yes"):
            str_out += "            BlockPockets                 %s\n"%(block)
            str_out += "            BlockPocketsFilename         %s\n"%(structure)
        str_out += "            TranslationProbability       1.0\n"
        #str_out += "            RotationProbability          1.0\n"
        str_out += "            ReinsertionProbability       1.0\n"
        str_out += "            SwapProbability              1.0\n"
        str_out += "            CreateNumberOfMolecules      0\n"
        str_out += "\n"
        fo.write(str_out)
        fo.close()



def GCMC2(cycles, structure, unitcell, T, P, molecule, block):
    # T and P are in (K) and (Pa) respectively
    with open("simulation.input","a+") as fo1:
        str_out = ""
        str_out += "Component 1 MoleculeName                 %s\n"%(molecule)
        str_out += "            MoleculeDefinition           local\n"
        if (block == "yes"):
            str_out += "            BlockPockets                 %s\n"%(block)
            str_out += "            BlockPocketsFilename         %s\n"%(structure)
        str_out += "            TranslationProbability       1.0\n"
        str_out += "            RotationProbability          1.0\n"
        str_out += "            ReinsertionProbability       1.0\n"
        str_out += "            SwapProbability              1.0\n"
        str_out += "            CreateNumberOfMolecules      0\n"
        fo.write(str_out)
        fo1.close()









# Extract loading and heat of adsorption from a GCMC output file
def extract_GCMC(structure, unitcell, T, P):
    with open ("output_"+ structure + "_" + str(unitcell[0]) + "." +
               str(unitcell[1]) + "." + str(unitcell[2]) + "_" +
               str(T) + ".000000_" + str(P) + ".data", 'r') as fi:
        data = fi.readlines()
        for line in data:
            if "Enthalpy of adsorption:" in line:
                Q_line = data[data.index(line) + 10]
                Q = float(Q_line.split()[0])
            elif "Average loading absolute [mol/kg framework]" in line:
                L = float(line.split()[5])
    fi.close()
    # L (mmol/g) and Q (J/mmol)
    return L, Q

# Create job.bash file to run RASPA
def slurm(structure):
    with open("job2.bash","w") as fo:
        str_out = ""
        str_out += "#!/bin/bash\n\n"
        str_out += "#SBATCH --no-requeue\n"
        str_out += "#SBATCH --wait\n"
        str_out += "#SBATCH --job-name   %s\n"%(structure)
        str_out += "#SBATCH --get-user-env\n"
        str_out += "#SBATCH --output     jobout.txt\n"
        str_out += "#SBATCH --error      joberr.txt\n"
        str_out += "#SBATCH --nodes      1\n"
        str_out += "#SBATCH --ntasks     1\n"
        str_out += "#SBATCH --partition  serial\n"
        str_out += "#SBATCH --time       05:00:00\n\n"
        str_out += "export RASPA_DIR=/home/kjablonk/RASPA/simulations/\n"
        str_out += "export DYLD_LIBRARY_PATH=/home/kjablonk/RASPA/simulations/lib\n"
        str_out += "export LD_LIBRARY_PATH=/home/kjablonk/RASPA/simulations/lib\n\n"
        str_out += "/home/kjablonk/RASPA/simulations/bin/simulate 'simulation.input'\n"
        fo.write(str_out)
        fo.close()

# Run RASPA calculations
def read_RASPA(structure, molecule, unitcell, T):
    #extract_widom(structure, molecule, unitcell, T)  
    #slurm(structure)
    #subprocess.Popen(["bash", "job2.bash"])
    #GCMC1(cycles, structure, unitcell, T, P, molecule, block)
    #slurm(structure)
    #subprocess.call('simulate') this is for localpc
    #subprocess.call(["bash", "job2.bash"])
    #subprocess.Popen(["bash", "job2.bash"])
    
    current_dir = os.getcwd()
    new_dir = os.path.join(current_dir, structure+"_pfolder","Output", "System_0")
    print(new_dir)
    #try:
    os.chdir(new_dir)
    kh, kh_err,q_kh, q_kh_err = extract_widom(structure, molecule, unitcell, T)
    #changing directories may cause error sometimes..expecially inside if statements...Soumik...be careful...can use os.path.join instead....see gcmc of co2 ..binary litcic codes
    os.chdir(current_dir)
    print(kh,kh_err, q_kh, q_kh_err)
    #return L, Q
    #except:
    #    with open("no_output_binary","a+") as fo:
    #        str_out = ""
    #        #str_out += "Structure" +  "      " +  "No Output file generated" + "\n"
    #        str_out +=  structure.split('.')[0]+".cif" + "\n"

    return kh, kh_err, q_kh, q_kh_err

