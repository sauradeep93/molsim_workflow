#!/home/sauradeepmajumdar/anaconda3/bin/python

from gcmc_prepare_henry import*
#import argparse
import math
#import yaml
#import json
#import numpy as np 
#import networkx as nx
#from scipy.spatial import distance
#import sys
#import math
import os
import subprocess
import shutil
#from collections import deque
#import matplotlib.pyplot as plt



def cifs(extension):
    curr_directory = os.getcwd()
   # new_directory = os.path.join(curr_directory, "cifs")
    list_cifs = []

    for f in os.listdir(curr_directory):
        if f.endswith('.' + extension):
            list_cifs.append(f)

    return list_cifs


#list containing all the cif files in the database
list_cifs = cifs("cif")




path =os.getcwd()

for i in list_cifs:
    print(i)


  
  

    ########################################## GCMC runs ##################################################################################################3






    #print(i.split('.')[0]+"_opt.cif_EQeq_Ewald_1.20_-2.00" +".cif")

    #Get the cell parameters
    
    unitcell=extract_geometry(i.rsplit('.',1)[0]) 
    #unitcell=extract_geometry(structure.rsplit('.',1)[0])
    print(unitcell)



    #Run zeo ++ calculations - blocking spheres...can extract other properties like density,pore volume, predicted saturation capacity
    #zeo(i.split('.')[0]+"_opt.cif_EQeq_Ewald_1.20_-2.00")

    # Check if the block file is empty or not
    with open(i.rsplit('.',1)[0] + ".block") as f9:
        if "0" in f9.readline():
            block = "no"
        else:
            block = "yes"
        f9.close()





    molecule0 = "CO2"       # You can change it to N2
    molecule1 = "N2"
    molecule2 = "H2"
    molecule3 = "CH4"
    molecule4 = "H2S"
    molecule5 = "H2O"
    T_ads = 298.15            # Adsorption temperature (K)
   # T_des = 363            # Desorption temperature (K)
   # P_ads = 10000000         # Adsorption pressure (Pa)
   # P_des = 10000          # Desorption pressure (Pa)
    cycles = 50000          # Number of cycles

    run_RASPA(i.rsplit('.',1)[0], unitcell, T_ads, molecule0, block, cycles)
   # run_RASPA(i.split('.')[0], unitcell, T_des, molecule, block, cycles, P_des)

    

