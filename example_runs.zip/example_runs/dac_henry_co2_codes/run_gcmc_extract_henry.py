from gcmc_extract_henry import *


def cifs(extension):
    directory = os.getcwd()
    structure_list = []

    for f in os.listdir(directory):
        if f.endswith('.' + extension):
            structure_list.append(f)

    return structure_list



structure_list= cifs("cif")


for structure in structure_list:
    print(structure)


    #Get the cell parameters
    try:
        unitcell=unitcell=extract_geometry(structure.split('.cif')[0])
    except Exception as e1:
        print(e1)
        print('No unit cell parameters found;moving on to next structure')
        continue
    #print(unitcell)
   





    molecule0 = "CH4"       # Can be N2 too
    molecule1="N2"
    molecule2="H2S"
    molecule3="CO2"
    T_ads = 298.15            # Adsorption temperature (K)
    T_des = 363            # Desorption temperature (K)
    P_ads = 10000000         # Adsorption pressure (Pa)
    P_des = 10000          # Desorption pressure (Pa)
    cycles = 10000          # Number of cycles

    #run_RASPA(structure.rsplit('.',1)[0], unitcell, T_ads, molecule, block, cycles, P_ads)
    #run_RASPA(structure.rsplit('.',1)[0], unitcell, T_des, molecule, block, cycles, P_des)

    path=os.getcwd()
    try:
        kh, kh_error,q_kh,q_kh_err = read_RASPA(structure.split('.cif')[0], molecule3, unitcell, T_ads)
        #print(Lads,Qads,"2") 
        with open("henry_298.15_co2_dac_pre_training_test.csv","a+") as fo:
            str_out = ""
            #str_out += "Structure" + "," + "CO2 uptake" + "," + "N2 uptake" + "\n"
            str_out +=  structure.split('.cif')[0].replace(",","_" )+".cif" + "," + str(kh) + ','+str(kh_error)+"," + str(q_kh)+ ',' +str(q_kh_err) +"\n"

            fo.write(str_out)
            fo.close()

    except Exception as e:

        #print("Output file not generated 1")
        print(e)
        print(path)
        os.chdir(path)   #check gcmc_h2_extract.py  need to change this directory so that there is no difficulty in finding the next cif file in the list
        with open("no_output_henry_298.15_co2_dac_pre_training_test.csv","a+") as fo:
            str_out = ""
            #str_out += "Structure" +  "      " +  "No Output file generated" + "\n"
            str_out +=  structure.split('.')[0].replace(",","_" )+".cif" + "\n"

            fo.write(str_out)
            fo.close()                                  
