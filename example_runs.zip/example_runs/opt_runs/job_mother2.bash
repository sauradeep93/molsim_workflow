#!/bin/bash


#extracting opt_cifs from dump files of all structures

for i in *.cif ; do


cp job_post_optimize.bash "${i%????}"_folder


cd "${i%????}"_folder
sed -i "s/__struc__/$i/" job_post_optimize.bash

sbatch job_post_optimize.bash
sleep 1s

cd ../
done



