#!/bin/bash


#submitting lammps-interface job and lammps job  for all cif files

for i in *.cif ; do

mkdir "${i%????}"_folder
cp $i "${i%????}"_folder
cp job_optimize.bash "${i%????}"_folder


cd "${i%????}"_folder
sed -i "s/__struc__/$i/" job_optimize.bash

sbatch job_optimize.bash
sleep 1s

cd ../
done



