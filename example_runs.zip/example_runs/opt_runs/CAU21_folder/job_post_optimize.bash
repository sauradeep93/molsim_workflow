#!/bin/bash

#SBATCH --no-requeue
#SBATCH --job-name   optCAU21.cif
#SBATCH --get-user-env
#SBATCH --mem 5GB
#SBATCH --nodes      1
#SBATCH --ntasks     1
#SBATCH --time       2:00:00




#module purge
##module load intel/18.0.5 intel-mkl/2018.5.274 intel-mpi/2018.4.274 lammps
#module load intel
#module load intel-mkl
#module load intel-mpi
#module reload
#lmp="/work/lsmo/binRaffa/lmpBTW"
#export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
#export MKL_NUM_THREADS=$SLURM_CPUS_PER_TASK
#srun $lmp -sf intel -i in.*
#wait

#lmp_serial < in.*

python /home/majumdar/Programs/screening_gray/opt_codes/dump_extract.py
