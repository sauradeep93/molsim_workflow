#!/bin/bash


#submitting zeo and RASPA runs for all cif files

for i in *.cif ; do

mkdir "${i%????}"_pfolder
cp $i "${i%????}"_pfolder
cp force_field_mixing_rules.def "${i%????}"_pfolder
cp pseudo_atoms.def "${i%????}"_pfolder
cp CO2.def "${i%????}"_pfolder
#cp N2.def "${i%????}"_pfolder
#cp CH4.def "${i%????}"_pfolder  
cp UFF.rad "${i%????}"_pfolder
cp job_widom.bash "${i%????}"_pfolder


cd "${i%????}"_pfolder
sed -i "s/__struc__/$i/" job_widom.bash

sbatch job_widom.bash
sleep 0.5s

cd ../
done



