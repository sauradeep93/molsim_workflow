#!/bin/bash

#SBATCH --no-requeue
#SBATCH --job-name   co2CALF20.cif
#SBATCH --get-user-env
#SBATCH --mem 4GB
#SBATCH --nodes      1
#SBATCH --ntasks     1
#SBATCH --time       24:00:00


#1.525*80=1.22 CO2 probe radius
/work/lsmo/aiida-lsmo-codes/bin/network_46ce745_ubu18 -r UFF.rad -ha -block 1.220 500 CALF20.cif


python /work/lsmo/sauradeep/anglo_tests/adsorption/henry_files_anglo/run_gcmc_prepare_henry.py




export RASPA_DIR=/home/kjablonk/RASPA/simulations/
export DYLD_LIBRARY_PATH=/home/kjablonk/RASPA/simulations/lib
export LD_LIBRARY_PATH=/home/kjablonk/RASPA/simulations/lib

/home/kjablonk/RASPA/simulations/bin/simulate 'simulation.input'





