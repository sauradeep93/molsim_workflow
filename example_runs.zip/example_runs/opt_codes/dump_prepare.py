#!/home/sauradeepmajumdar/anaconda3/bin/python

#from adsorption import *
#import argparse
import math
#import yaml
#import json
#import numpy as np 
#import networkx as nx
#from scipy.spatial import distance
#import sys
#import math
import os
import subprocess
import shutil
#from collections import deque
#import matplotlib.pyplot as plt





############################################### Modifying the input and data files created from lammps_interface #######################################33



def cifs(extension):
    curr_directory = os.getcwd()
   # new_directory = os.path.join(curr_directory, "cifs")
    list_cifs = []

    for f in os.listdir(curr_directory):
        if f.endswith('.' + extension):
            list_cifs.append(f)

    return list_cifs


#list containing all the cif files in the database
list_cifs = cifs("cif")




path =os.getcwd()

for i in list_cifs:
    print(i)

        
    with open("data." + i.split('.cif')[0], "r") as f0:
        data = f0.read().splitlines()
        c=c1=c2=0
        for line in data:
            c = c+1
            if "Masses" in line:
                c1 = c
            if "Bond Coeffs" in line:
                c2 =c

        c4=(c2-3)-(c1+1)+1 
        a=c1+1
       
        atom_type=" "
        while(a>c1 and a<(c2-2)):
            atom_type +=(data[a].split('#')[1])
            a=a+1

    with open("in." + i.split('.cif')[0], "r") as f1:
        data = f1.readlines()
        data1 =  data[0:22]
        data2 =  data[22:len(data)]
        f1.close() 
    
    os.remove("in." + i.split('.cif')[0])
    with open("in." + i.split('.cif')[0], "w") as f2:
        str_out = ""
        for j in data1:
            str_out+=j
        #str_out+="dump" + "            " + i.split('.')[0] + "_xyzmov"+ " " +"all xyz 100" + " " +  i.split('.')[0] + "_mov.xyz\n"
        #str_out+="dump_modify" + "     "  +   i.split('.')[0] + "_xyzmov element" + " " + atom_type + "\n"
        str_out+="dump            d1 all custom 500" + " " + "dump." + i.split('.cif')[0] + " "+ "element xs ys zs\n"
        str_out+="dump_modify     d1 element" + atom_type +"\n"
       
        for k in data2:
            str_out+=k
        #str_out+="undump"+ "          "+ i.split('.')[0] + "_xyzmov"
        str_out+="\n"
        f2.write(str_out)
        f2.close()
       
    
    ####################################################### Next step running energy minimization in lammps using input and data files generated from lammps_interface#################################
