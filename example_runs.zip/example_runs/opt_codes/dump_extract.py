#!/home/sauradeepmajumdar/anaconda3/bin/python

#from adsorption import *
#import argparse
import math
#import yaml
#import json
#import numpy as np 
#import networkx as nx
#from scipy.spatial import distance
#import sys
#import math
import os
import subprocess
import shutil
#from collections import deque
#import matplotlib.pyplot as plt





    # EXTRACTING THE COORDINATES OF THE LAST FRAME FROM DUMP FILES OF LAMMPS AND CONVERTING IT TO CIF FILES


def dumps(extension):
    curr_directory = os.getcwd()
   # new_directory = os.path.join(curr_directory, "cifs")
    list_dumps = []

    for f in os.listdir(curr_directory):
        if f.startswith(extension + '.' ):
            list_dumps.append(f)

    return list_dumps


#list containing all dump  files in the folder
list_dumps = dumps("dump")




path =os.getcwd()

for i in list_dumps:
    print(i)







    with open("dump." + i.split('dump.')[1], "r") as f4, open(i.split('dump.')[1]+".dump","w+") as f5:
        data=f4.readlines()
        f4.close()
        n_atoms= int(data[3])
        #print(n_atoms)
        #for row in f4.readlines()[-(n_atoms+9):]:
        for row in data[-(n_atoms+9):]:
            f5.write(row)
        f4.close()
        f5.close()

    file_path_opt = os.path.join(path, "opt_cifs", i.split('dump.')[1]+"_opt.cif")
    with open(i.split('dump.')[1]+".dump","r") as f6, open(i.split('dump.')[1]+"_opt.cif","w+") as f7:
   # with open(i.split('.')[1]+".dump","r") as f6, open(file_path_opt,"w+") as f7: 
        data = f6.read().splitlines()
        f6.close()

        for line in data:
            if line=='':
                data.remove(line)

        #start of cell parameters calculation

        yy=' '.join(data[5:8])
        #for i in yy.split():
        #  print(i,float(i))
        values=[float(i) for i in yy.split()]
        print(values)
        print(values[0])


        xlo_bound=values[0]
        xhi_bound=values[1]
        xy=values[2]
        ylo_bound=values[3]
        yhi_bound=values[4]
        xz=values[5]
        zlo_bound=values[6]
        zhi_bound=values[7]
        yz=values[8]
        xlo=xlo_bound-min(0.0,xy,xz,xy+xz)
        xhi=xhi_bound-max(0.0,xy,xz,xy+xz)
        ylo=ylo_bound-min(0.0,yz)
        yhi=yhi_bound-max(0.0,yz)
        zlo=zlo_bound
        zhi=zhi_bound
        lx=xhi-xlo
        ly=yhi-ylo
        lz=zhi-zlo
        a=lx
        b= math.sqrt(math.pow(ly,2)+ math.pow(xy,2))
        c= math.sqrt(math.pow(lz,2)+ math.pow(xz,2) + math.pow(yz,2))
        alph= math.acos(((xy*xz)+(ly*yz))/(b*c))
        bet= math.acos(xz/c)
        gamm = math.acos(xy/b)
        alpha =math.degrees(alph)
        beta =math.degrees(bet)
        gamma =math.degrees(gamm)
        print(a,b,c,alpha,beta,gamma)
   
        #end of cell parameters calculation



        count = 0
        count_lim = 0
        loop_list = []
        atom_site_list = []

        for line in data:
            count_lim += 1
        print(count_lim)
        data = data [0:count_lim]## need to put correct line number
        flags = data[9:len(data)] #first 9 lines(0 -8) do  not contain the coordinates
        print(len(data))
        print(len(flags))

        str_out=""
        str_out+=("CIF file\n")
        str_out+=("loop_\n")
        str_out+=("_symmetry_equiv_pos_as_xyz\n")
        str_out+=("\'x, y, z\'\n")
        str_out+=("_symmetry_space_group_name_H-M    P1\n")
        str_out+=("_symmetry_Int_Tables_number       1\n")
        str_out+=("_cell_length_a"+ " " + str(a) +"\n")
        str_out+=("_cell_length_b" + " " + str(b) + "\n")
        str_out+=("_cell_length_c" + " " + str(c) + "\n")
        str_out+=("_cell_angle_alpha" + " " + str(alpha) +"\n")
        str_out+=("_cell_angle_beta" + " " + str(beta) + "\n")
        str_out+=("_cell_angle_gamma" + " " + str(gamma) +"\n")
        str_out+=("loop_\n")
        str_out+=("_atom_site_type_symbol\n")
        str_out+=("_atom_site_label\n")
        str_out+=("_atom_site_fract_x\n")
        str_out+=("_atom_site_fract_y\n")
        str_out+=("_atom_site_fract_z\n")



        for j in range(0, len(flags)):
            a = flags[j].split()
    
            if "Ti6+4" in a[0]:
                a.append("Ti")
            
            if "Zr3+4" in a[0]:
                a.append("Zr")

            if "Co6+3" in a[0]:
                a.append("Co")

            if "Cu3+1" in a[0]:
                a.append("Cu")

            if "Ni4+2" in a[0]:
                a.append("Ni")

            if "Zn3+2" in a[0]:
                a.append("Zn")
  
            if "Cd3+2" in a[0]:
                a.append("Cd")

            if "Mn6+2" in a[0]:
                a.append("Mn")

            if "Pb3" in a[0]:
                a.append("Pb")
          
            if "O_2" in a[0]:
                a.append("O")

            if "O_R" in a[0]:
                a.append("O")
  
            if "O_3" in a[0]:
                a.append("O")
           
            if "H_" in a[0]:
                a.append("H")
    
            if "N_R" in a[0]:
               a.append("N")

            if "N_3" in a[0]:
               a.append("N")
           
            if "N_2" in a[0]:
               a.append("N") 
           
            if "C_3" in a[0]:
               a.append("C")
 
            if "C_R" in a[0]:
               a.append("C")

            if "C_2" in a[0]:
               a.append("C")

            if "C_1" in a[0]:
               a.append("C")
    
            if "N_1" in a[0]:
               a.append("N")
            
            if "F_" in a[0]:
               a.append("F")

            if "Cl" in a[0]:
               a.append("Cl")
 
            if "I_" in a[0]:
               a.append("I")

            if "Br" in a[0]:
               a.append("Br")
            

            if "P_3+q" in a[0]:
               a.append("P")

            if "S_3+6" in a[0]:
               a.append("S")
            
            if "S_R" in a[0]:
               a.append("S")
            
            if "Li" in a[0]:
               a.append("Li")

            if "Na" in a[0]:
               a.append("Na")            
            
            if "La3+3" in a[0]:
               a.append("La")
            
            if "Cr6+3" in a[0]:
               a.append("Cr")
            
            if "Lu6+3" in a[0]:
               a.append("Lu")

            if "Al3" in a[0]:
               a.append("Al")

            if "Fe6+2" in a[0]:
               a.append("Fe")

            if "Sm6+3" in a[0]:
               a.append("Sm")


            if "Dy6+3" in a[0]:
               a.append("Dy")


            if "Mn6+3" in a[0]:
               a.append("Mn")

            if "Cu3+1" in a[0]:
               a.append("Cu")

            if "In3+3" in a[0]:
               a.append("In")

            if "Mg6" in a[0]:
               a.append("Mg")


            if "V_3+5" in a[0]:
               a.append("V")



            if "Ga3+3" in a[0]:
               a.append("Ga")


            if "Ag1+1" in a[0]:
               a.append("Ag")


            if "U_6+4" in a[0]:
               a.append("U")


            if "Tb6+3" in a[0]:
               a.append("Tb")


            if "Er6+3" in a[0]:
               a.append("Er")

         
            if "Sr6+2" in a[0]:
               a.append("Sr")


            if "W_3+6" in a[0]:
               a.append("W")



            if "Gd6+3" in a[0]:
               a.append("Gd")



            if "Eu6+3" in a[0]:
               a.append("Eu")

            if "Ca6+2" in a[0]:
               a.append("Ca")


            if "Rb" in a[0]:
               a.append("Rb")

            
            if "Au4+3" in a[0]:
               a.append("Au")

            if "K" in a[0]:
               a.append("K")

            if "Ho6+3" in a[0]:
               a.append("Ho")

            if "Nd6+3" in a[0]:
               a.append("Nd")



            if "Y_3+3" in a[0]:
               a.append("Y")

            if "Mg6" in a[0]:
               a.append("Mg")
            
            if "Mg3+2" in a[0]:
               a.append("Mg")
            
            if "La3+3" in a[0]:
               a.append("La")
            
            if "Ru6+2" in a[0]:
               a.append("Ru")


            if "Ba6+2" in a[0]:
               a.append("Ba")
            
            if "Pr6+3" in a[0]:
               a.append("Ru")
            if "Si3" in a[0]:
               a.append("Si")

            if "Ce6+3" in a[0]:
               a.append("Ce")
            
            if "Nb3+5" in a[0]:
               a.append("Nb")
            
            str_out+=((a[4])+ "  " +(a[4])+ "  "+(a[1])+ "  "+(a[2])+"  "+ (a[3]))
            str_out+="\n"
        
        str_out+=("_end")
        str_out+="\n"
        f7.write(str_out)
        f7.close()
    

    
    #file_path_charge = os.path.join(path, "charge_cifs", i.split('.')[0]+"_opt.cif")    
