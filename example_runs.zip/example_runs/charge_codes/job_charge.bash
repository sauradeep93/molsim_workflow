#!/bin/bash

#SBATCH --no-requeue
#SBATCH --job-name   cg__struc__
#SBATCH --get-user-env
#SBATCH --mem 4GB
#SBATCH --nodes      1
#SBATCH --ntasks     1
#SBATCH --time       24:00:00

/work/lsmo/aiida-lsmo-codes/bin/eqeq_6490320_ubu18 __struc__




