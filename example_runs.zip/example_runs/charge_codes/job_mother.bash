#!/bin/bash


#submitting EQeq calculations for all cif files

for i in *.cif ; do

mkdir "${i%????}"_folder
cp $i "${i%????}"_folder
cp ionizationdata.dat "${i%????}"_folder
cp chargecenters.dat "${i%????}"_folder
cp job_charge.bash "${i%????}"_folder


cd "${i%????}"_folder
sed -i "s/__struc__/$i/" job_charge.bash

sbatch job_charge.bash
sleep 0.5s

cd ../
done



